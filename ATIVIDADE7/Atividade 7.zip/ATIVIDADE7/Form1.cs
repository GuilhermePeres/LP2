﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATIVIDADE7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLer20_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];

            int x = 0;
            string auxiliar = "";
            string valor = "";

            for (x=0; x<20; x++)
            {
                valor = Interaction.InputBox("Digite o dado" +  (x+1), "Entrada de dados");

                if (int.TryParse(valor, out vetor[x]))
                    auxiliar = vetor[x].ToString() + "\n" + auxiliar;
                //ou 
                // for (x=19; x>=0; x--)
                //      auxiliar = auxiliar + "\n" vetor[x].ToString();
                else
                {
                    MessageBox.Show("Número Inválido!");
                    x--;
                }
            }
            MessageBox.Show(auxiliar);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            int x = 0;
            string auxiliar = "";
            string valor = "";

            for (x = 0; x < 20; x++)
            {
                valor = Interaction.InputBox("Digite o dado", "Entrada de dados (" + (x + 1) + "° valor)");

                if (!int.TryParse(valor, out vetor[x]))
                {
                    MessageBox.Show("Número inválido!");
                    x--;
                }

            }

            Array.Reverse(vetor);

            foreach (int n in vetor)
                auxiliar += n + "\n";

            MessageBox.Show(auxiliar);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[10];
            int x = 0;
            string quantidade;
            string valor;
            double faturamento;
            double[] quantidades = new double[10];
            double[] valores = new double[10];

            faturamento = 0;
       
       
           for (x=0; x<10; x++)
           {
                quantidade = Interaction.InputBox("Digite a quantidade da " + (x + 1) + "° Mercadoria");
                if (!double.TryParse(quantidade, out quantidades[x]))
                {
                    MessageBox.Show("Número Inválido!");
                    x--;
                    continue;
                }
                
                valor = Interaction.InputBox("Digite o valor em reais ");
                if (!double.TryParse(valor, out valores[x]))
                {
                    MessageBox.Show("Número Inválido!");
                    x--;
                    continue;
                }

               faturamento += valores[x] * quantidades[x];            
           }

           MessageBox.Show("O faturamento mensal foi de: " + faturamento);
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
                Total += Alunos[I].Length;
            MessageBox.Show(Total.ToString());
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList();

            alunos.Add("Ana");
            alunos.Add("André");
            alunos.Add("Débora");
            alunos.Add("Fátima");
            alunos.Add("João");
            alunos.Add("Janete");
            alunos.Add("Otávio");
            alunos.Add("Marcelo");
            alunos.Add("Pedro");
            alunos.Add("Thais");

            alunos.Remove("Otávio");

            string nomes = "";

            foreach (string nome in alunos)
                nomes += nome + "\n";

            MessageBox.Show(nomes);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int i, t;
            string nota;
            double[,] notas = new double[20, 3];
            double media;

            for (i = 0; i < 19; i++)
            {
                for (t = 0; t < 3; t++)
                {
                    nota = Interaction.InputBox("Insira a nota do aluno " + (i + 1) + ". " + "Nota " + (t + 1) + ":");
                    if (!double.TryParse(nota, out notas[i, t]))
                    {
                        MessageBox.Show("Número inválido!");
                        t--;
                        continue;
                    }
                }
            }

            for (i = 0; i < 19; i++)
            {
                media = (notas[i, 0] + notas[i, 1] + notas[i, 2]) / 3;
                MessageBox.Show("Aluno " + (i + 1) + ": média: " + media + "\n");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            frm2.Show();
        }
    }
}
