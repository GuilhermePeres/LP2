﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATIVIDADE7
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            Int64 RA, n;
            int i, cont;
            ArrayList Lista = new ArrayList();
            string nome;

            //0030481921019

            Int64.TryParse(Interaction.InputBox("Digite o RA"), out RA);

            n = RA % 10;

            if (n == 0)
            {
                n = 10;
            }

            for (i = 0; i < n; i++)
            {
                nome = Interaction.InputBox("Digite o " + (i + 1) + " nome:");
                Lista.Add(nome);
            }

            foreach(string c in Lista)
            {
                cont = 0;
                foreach(char t in c)
                {
                    if (!Char.IsWhiteSpace(t))
                    {
                        cont++;
                    }
                }
                rtbxNomes.Text = rtbxNomes.Text + "\n O nome " + c + "tem " + cont + " caracteres.";
            }
        }

        private void lbxNomes_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
