﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade6
{
    public partial class formExercício3 : Form
    {
        public formExercício3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            //passando para maiúscula
            string maiuscula = txtFrase.Text.ToUpper();

            //removendo espaços em branco
            string tudoJunto = maiuscula.Replace(" ", "");

            //removendo acentos
            byte[] bytes = System.Text.Encoding.GetEncoding("iso-8859-8").GetBytes(tudoJunto);
            string semAcento = System.Text.Encoding.UTF8.GetString(bytes);

            //invertendo frase
            string invertida = new string(semAcento.Reverse().ToArray());

            if (String.Compare(semAcento, invertida, true) == 0)
            {
                MessageBox.Show("É um palíndromo");
            }
            else
            {
                MessageBox.Show("Não é um palíndromo");
            }

        }
    }
}
