﻿namespace Atividade6
{
    partial class formExercício2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNum = new System.Windows.Forms.TextBox();
            this.lblInsiraOnumero = new System.Windows.Forms.Label();
            this.btnGerarNum = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtNum
            // 
            this.txtNum.Location = new System.Drawing.Point(41, 93);
            this.txtNum.Name = "txtNum";
            this.txtNum.Size = new System.Drawing.Size(128, 26);
            this.txtNum.TabIndex = 0;
            this.txtNum.TextChanged += new System.EventHandler(this.txtNum_TextChanged);
            // 
            // lblInsiraOnumero
            // 
            this.lblInsiraOnumero.AutoSize = true;
            this.lblInsiraOnumero.Location = new System.Drawing.Point(37, 50);
            this.lblInsiraOnumero.Name = "lblInsiraOnumero";
            this.lblInsiraOnumero.Size = new System.Drawing.Size(298, 20);
            this.lblInsiraOnumero.TabIndex = 1;
            this.lblInsiraOnumero.Text = "Insira o número N para gerar o número H";
            // 
            // btnGerarNum
            // 
            this.btnGerarNum.Location = new System.Drawing.Point(41, 195);
            this.btnGerarNum.Name = "btnGerarNum";
            this.btnGerarNum.Size = new System.Drawing.Size(135, 83);
            this.btnGerarNum.TabIndex = 2;
            this.btnGerarNum.Text = "Gerar Número H";
            this.btnGerarNum.UseVisualStyleBackColor = true;
            this.btnGerarNum.Click += new System.EventHandler(this.btnGerarNum_Click);
            // 
            // formExercício2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnGerarNum);
            this.Controls.Add(this.lblInsiraOnumero);
            this.Controls.Add(this.txtNum);
            this.Name = "formExercício2";
            this.Text = "Exercício 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNum;
        private System.Windows.Forms.Label lblInsiraOnumero;
        private System.Windows.Forms.Button btnGerarNum;
    }
}