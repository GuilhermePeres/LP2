﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade6
{
    public partial class formExercício1 : Form
    {
        public formExercício1()
        {
            InitializeComponent();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int x = -1;
            int i;

            for (i = 0; i < rchtxtTexto.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchtxtTexto.Text[i]))
                {
                    x += 1;
                }
            }

            MessageBox.Show("O número de espaços em branco que existem na frase é: " + (x + 1));
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int i;
            string letra = "R";
            string letrinha = "r";

            for (i = 0; i < rchtxtTexto.Text.Length; i++)
            {
                if (String.Compare(Char.ToString(rchtxtTexto.Text[i]), letra, true) == 0 ||
                    String.Compare(Char.ToString(rchtxtTexto.Text[i]), letrinha, true) == 0)
                {
                    contador += 1;
                }
            }

            MessageBox.Show("Número de vezes que aparece a letra R: " + contador);
        }

        private void btnPar_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int i;
            string anterior;
            string proxima;

            for (i = 0; i < rchtxtTexto.Text.Length - 1; i++)
            {
                anterior = Char.ToString(rchtxtTexto.Text[i]);
                proxima = Char.ToString(rchtxtTexto.Text[i + 1]);

                if (String.Compare(anterior, proxima, true) == 0)
                {
                    contador += 1;
                }
            }

            MessageBox.Show("Número de vezes que aparece um par de letras: " + contador);
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            formExercício2 frm2 = new formExercício2();
            frm2.MdiParent = this;
            frm2.WindowState = FormWindowState.Maximized;
            frm2.Show();
        }
    }
}
