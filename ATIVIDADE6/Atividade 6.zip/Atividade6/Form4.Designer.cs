﻿namespace Atividade6
{
    partial class formExercício4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTítulo = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblCargo = new System.Windows.Forms.Label();
            this.lblNumInscri = new System.Windows.Forms.Label();
            this.lblProdução = new System.Windows.Forms.Label();
            this.lblSalário = new System.Windows.Forms.Label();
            this.lblGratific = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtCargo = new System.Windows.Forms.TextBox();
            this.txtNumInscri = new System.Windows.Forms.TextBox();
            this.txtSalário = new System.Windows.Forms.TextBox();
            this.txtProdução = new System.Windows.Forms.TextBox();
            this.txtGratific = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTítulo
            // 
            this.lblTítulo.AutoSize = true;
            this.lblTítulo.Location = new System.Drawing.Point(315, 47);
            this.lblTítulo.Name = "lblTítulo";
            this.lblTítulo.Size = new System.Drawing.Size(162, 20);
            this.lblTítulo.TabIndex = 0;
            this.lblTítulo.Text = "Calcular Salário Bruto";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(41, 139);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(55, 20);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome:";
            // 
            // lblCargo
            // 
            this.lblCargo.AutoSize = true;
            this.lblCargo.Location = new System.Drawing.Point(41, 210);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(56, 20);
            this.lblCargo.TabIndex = 2;
            this.lblCargo.Text = "Cargo:";
            // 
            // lblNumInscri
            // 
            this.lblNumInscri.AutoSize = true;
            this.lblNumInscri.Location = new System.Drawing.Point(230, 139);
            this.lblNumInscri.Name = "lblNumInscri";
            this.lblNumInscri.Size = new System.Drawing.Size(157, 20);
            this.lblNumInscri.TabIndex = 3;
            this.lblNumInscri.Text = "Número de inscrição:";
            // 
            // lblProdução
            // 
            this.lblProdução.AutoSize = true;
            this.lblProdução.Location = new System.Drawing.Point(230, 210);
            this.lblProdução.Name = "lblProdução";
            this.lblProdução.Size = new System.Drawing.Size(81, 20);
            this.lblProdução.TabIndex = 5;
            this.lblProdução.Text = "Produção:";
            // 
            // lblSalário
            // 
            this.lblSalário.AutoSize = true;
            this.lblSalário.Location = new System.Drawing.Point(41, 278);
            this.lblSalário.Name = "lblSalário";
            this.lblSalário.Size = new System.Drawing.Size(62, 20);
            this.lblSalário.TabIndex = 6;
            this.lblSalário.Text = "Salário:";
            // 
            // lblGratific
            // 
            this.lblGratific.AutoSize = true;
            this.lblGratific.Location = new System.Drawing.Point(230, 278);
            this.lblGratific.Name = "lblGratific";
            this.lblGratific.Size = new System.Drawing.Size(99, 20);
            this.lblGratific.TabIndex = 7;
            this.lblGratific.Text = "Gratificação:";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(45, 167);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 26);
            this.txtNome.TabIndex = 8;
            // 
            // txtCargo
            // 
            this.txtCargo.Location = new System.Drawing.Point(45, 233);
            this.txtCargo.Name = "txtCargo";
            this.txtCargo.Size = new System.Drawing.Size(100, 26);
            this.txtCargo.TabIndex = 9;
            // 
            // txtNumInscri
            // 
            this.txtNumInscri.Location = new System.Drawing.Point(234, 167);
            this.txtNumInscri.Name = "txtNumInscri";
            this.txtNumInscri.Size = new System.Drawing.Size(100, 26);
            this.txtNumInscri.TabIndex = 10;
            // 
            // txtSalário
            // 
            this.txtSalário.Location = new System.Drawing.Point(45, 301);
            this.txtSalário.Name = "txtSalário";
            this.txtSalário.Size = new System.Drawing.Size(100, 26);
            this.txtSalário.TabIndex = 12;
            // 
            // txtProdução
            // 
            this.txtProdução.Location = new System.Drawing.Point(234, 233);
            this.txtProdução.Name = "txtProdução";
            this.txtProdução.Size = new System.Drawing.Size(100, 26);
            this.txtProdução.TabIndex = 13;
            // 
            // txtGratific
            // 
            this.txtGratific.Location = new System.Drawing.Point(234, 301);
            this.txtGratific.Name = "txtGratific";
            this.txtGratific.Size = new System.Drawing.Size(100, 26);
            this.txtGratific.TabIndex = 14;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(447, 233);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(158, 93);
            this.btnCalcular.TabIndex = 15;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // formExercício4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtGratific);
            this.Controls.Add(this.txtProdução);
            this.Controls.Add(this.txtSalário);
            this.Controls.Add(this.txtNumInscri);
            this.Controls.Add(this.txtCargo);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblGratific);
            this.Controls.Add(this.lblSalário);
            this.Controls.Add(this.lblProdução);
            this.Controls.Add(this.lblNumInscri);
            this.Controls.Add(this.lblCargo);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblTítulo);
            this.Name = "formExercício4";
            this.Text = "Exercício 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTítulo;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblCargo;
        private System.Windows.Forms.Label lblNumInscri;
        private System.Windows.Forms.Label lblProdução;
        private System.Windows.Forms.Label lblSalário;
        private System.Windows.Forms.Label lblGratific;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtCargo;
        private System.Windows.Forms.TextBox txtNumInscri;
        private System.Windows.Forms.TextBox txtSalário;
        private System.Windows.Forms.TextBox txtProdução;
        private System.Windows.Forms.TextBox txtGratific;
        private System.Windows.Forms.Button btnCalcular;
    }
}