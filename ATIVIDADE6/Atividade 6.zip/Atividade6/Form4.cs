﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade6
{
    public partial class formExercício4 : Form
    {
        public formExercício4()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double B, C, D, Bruto;

            if (double.TryParse(txtGratific.Text, out double Gratific) &&
                double.TryParse(txtSalário.Text, out double A) &&
                double.TryParse(txtProdução.Text, out double Producao))
            {
                if(Producao >= 150)
                {
                    B = 0;
                    C = 0;
                    D = 1;

                    Bruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + Gratific;
                }
                else if(Producao >= 120)
                {
                    B = 0;
                    C = 1;
                    D = 0;

                    Bruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + Gratific;
                }
                else if(Producao >= 100)
                {
                    B = 1;
                    C = 0;
                    D = 0;

                    Bruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + Gratific;
                }
                else
                {
                    B = 0;
                    C = 0;
                    D = 0;

                    Bruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + Gratific;
                }

                if(Bruto > 7000.00)
                {
                    if(Producao >= 150 && Gratific != 0)
                    {
                        MessageBox.Show("Salário Bruto = " + Bruto);
                    }
                    else
                    {
                        MessageBox.Show("Salário Bruto = 7.000,00");
                    }
                }
                else
                {
                    MessageBox.Show("Salário Bruto = " + Bruto);
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira valores válidos.");
            }
        }
    }
}
