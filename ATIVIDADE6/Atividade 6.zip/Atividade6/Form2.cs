﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade6
{
    public partial class formExercício2 : Form
    {
        public formExercício2()
        {
            InitializeComponent();
        }

        private void txtNum_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnGerarNum_Click(object sender, EventArgs e)
        {
            float i;
            float valor = 0;

            if (float.TryParse(txtNum.Text, out float Num))
            {
                for (i = 1; i <= Num; i++)
                {
                    valor += 1/i;
                }

                if (valor != 0)
                {
                    MessageBox.Show("O número gerado foi: " + valor);
                }
                else
                {
                    MessageBox.Show("Não existe número a ser gerado");
                }
            }
        }
    }
}
