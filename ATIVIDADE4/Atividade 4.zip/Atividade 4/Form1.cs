﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnVerificarDesconto_Click(object sender, EventArgs e)
        {
            string NomeFunc, Sexo, EstadoCivil, Filhos, DireitaDaVirgula, EsquerdaDaVirgula;

            double SalLiqui, SalFamilia, DescINSS, DescIRPF;

            //verifica se existe um nome
            if (double.TryParse(mskbxNomeFuncionario.Text, out double Teste))
            {
                MessageBox.Show("Por favor insira um nome válido");
            }
            else
            {
                NomeFunc = mskbxNomeFuncionario.Text;

                //verifica se os valores numericos estão corretos
                if (double.TryParse(mskbxSalarioBruto.Text, out double SalBruto) &&
                    double.TryParse(mskbxNumeroDeFilhos.Text, out double NumFilhos))
                {
                    //verifica se o Sexo está selecionado
                    if (rbtnF.Checked == false && rbtnM.Checked == false)
                    {
                        MessageBox.Show("Por favor informe seu sexo");
                    }
                    else //caso tudo esteja correto executa abaixo
                    {
                        //Arruma o Salario Bruto de acordo com a vírgula
                        SalBruto /= 100;

                        //verifica se é Sr ou Sra
                        if (rbtnF.Checked == true)
                        {
                            Sexo = "da Sra.";
                        }
                        else
                        {
                            Sexo = "do Sr.";
                        }
                        //verifica se é casado ou solteiro
                        if (ckbxCasado.Checked == true)
                        {
                            EstadoCivil = "Casado(a) ";
                        }
                        else
                        {
                            EstadoCivil = "Solteiro(a) ";
                        }
                        //verifica se tem ou não filhos
                        if (NumFilhos == 00)
                        {
                            Filhos = "não tem filhos são:";
                        }
                        else if (NumFilhos >= 01)
                        {
                            Filhos = "tem " + NumFilhos + " filho(s) são:";
                        }
                        else //para tirar o erro da atribuição da variável filhos no lblDados
                        {
                            Filhos = "não tem filhos são:";
                        }
                        
                        lblDados.Text = "Os descontos do salário " + Sexo +
                            NomeFunc + "\nque é " + EstadoCivil + "\ne que " + Filhos;

                        //Aliquota INSS
                        if (SalBruto <= 800.47)
                        {
                            mskbxAliquotaINSS.Text = "7.65%";
                            DescINSS = (7.65 / 100) * SalBruto;
                        }
                        else if (SalBruto <= 1050)
                        {
                            mskbxAliquotaINSS.Text = "8.65%";
                            DescINSS = (8.65 / 100) * SalBruto;
                        }
                        else if (SalBruto <= 1400.77)
                        {
                            mskbxAliquotaINSS.Text = "9.00%";
                            DescINSS = (9.00 / 100) * SalBruto;
                        }
                        else if (SalBruto <= 2801.56)
                        {
                            mskbxAliquotaINSS.Text = "11.00%";
                            DescINSS = (11.00 / 100) * SalBruto;
                        }
                        else
                        {
                            mskbxAliquotaINSS.Text = "Teto";
                            DescINSS = 308.17;
                        }

                        mskbxDescontoINSS.Text = Convert.ToString(DescINSS);

                        //Aliquota IRPF
                        if (SalBruto <= 1257.12)
                        {
                            mskbxAliquotaIRPF.Text = "0";
                            DescIRPF = 0.00;
                        }
                        else if (SalBruto <= 2512.08)
                        {
                            mskbxAliquotaIRPF.Text = "15.00%";
                            DescIRPF = (15.00 / 100) * SalBruto;
                        }
                        else
                        {
                            mskbxAliquotaIRPF.Text = "27.5%";
                            DescIRPF = (27.5 / 100) * SalBruto;
                        }

                        mskbxDescontoIRPF.Text = Convert.ToString(DescIRPF);

                        //Salário Família
                        if (NumFilhos != 0)
                        {
                            if (SalBruto <= 435.52)
                                SalFamilia = NumFilhos * 22.33;

                            else if (SalBruto <= 654.61)
                                SalFamilia = NumFilhos * 15.74;

                            else
                                SalFamilia = 0.00;
                        }
                        else
                            SalFamilia = 0.00;

                        mskbxSalarioFamilia.Text = Convert.ToString(SalFamilia);

                        //Salario Liquido
                        SalLiqui = SalBruto - DescINSS - DescIRPF + SalFamilia;

                        mskbxSalarioLiquido.Text = Convert.ToString(SalLiqui);
                    }
                }
                else
                {
                    MessageBox.Show("Por favor insira valores válidos");
                }
            }
        }
    }
}
