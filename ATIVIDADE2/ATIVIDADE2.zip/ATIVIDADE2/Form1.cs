﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATIVIDADE2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mskbxPeso_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double PesoIdeal;

            if (double.TryParse(mskbxAltura.Text, out double Altura) &&
                double.TryParse(mskbxPeso.Text, out double Peso))
            {
                if (rbtnMasculino.Checked == false && rbtnFeminino.Checked == false)
                {
                    MessageBox.Show("Por favor informe seu sexo");
                }
                else
                {
                    if (rbtnMasculino.Checked == true)
                    {
                        PesoIdeal = (72.7 * Altura) - 58;

                        if (Peso > PesoIdeal)
                        {
                            MessageBox.Show("Regime Obrigatório Já");
                        }
                        else
                        {
                            if (Peso == PesoIdeal)
                            {
                                MessageBox.Show("Você está com o peso ideal");
                            }
                            else
                            {
                                if (Peso < PesoIdeal)
                                {
                                    MessageBox.Show("Coma bastante massas e doces");
                                }
                            }
                        }
                    }
                    else
                    {
                        PesoIdeal = (62.1 * Altura) - 44.7;

                        if (Peso > PesoIdeal)
                        {
                            MessageBox.Show("Regime Obrigatório Já");
                        }
                        else
                        {
                            if (Peso == PesoIdeal)
                            {
                                MessageBox.Show("Você está com o peso ideal");
                            }
                            else
                            {
                                if (Peso < PesoIdeal)
                                {
                                    MessageBox.Show("Coma bastante massas e doces");
                                }
                            }
                        }
                    }
                }
            }
            else
                MessageBox.Show("Por favor insira dados válidos");
        }
    }
}
