﻿namespace Atividade5
{
    partial class formExercício4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.rchtxtTexto = new System.Windows.Forms.RichTextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.btnNumerico = new System.Windows.Forms.Button();
            this.btnPrimeiro = new System.Windows.Forms.Button();
            this.btnAlfa = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtTexto
            // 
            this.rchtxtTexto.Location = new System.Drawing.Point(142, 28);
            this.rchtxtTexto.Name = "rchtxtTexto";
            this.rchtxtTexto.Size = new System.Drawing.Size(512, 184);
            this.rchtxtTexto.TabIndex = 0;
            this.rchtxtTexto.Text = "";
            this.rchtxtTexto.TextChanged += new System.EventHandler(this.rchtxtTexto_TextChanged);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // btnNumerico
            // 
            this.btnNumerico.Location = new System.Drawing.Point(172, 253);
            this.btnNumerico.Name = "btnNumerico";
            this.btnNumerico.Size = new System.Drawing.Size(134, 79);
            this.btnNumerico.TabIndex = 2;
            this.btnNumerico.Text = "Carcteres Numéricos\r\n";
            this.btnNumerico.UseVisualStyleBackColor = true;
            this.btnNumerico.Click += new System.EventHandler(this.btnNumerico_Click_1);
            // 
            // btnPrimeiro
            // 
            this.btnPrimeiro.Location = new System.Drawing.Point(325, 253);
            this.btnPrimeiro.Name = "btnPrimeiro";
            this.btnPrimeiro.Size = new System.Drawing.Size(141, 79);
            this.btnPrimeiro.TabIndex = 3;
            this.btnPrimeiro.Text = "Primeiro Branco\r\n";
            this.btnPrimeiro.UseVisualStyleBackColor = true;
            this.btnPrimeiro.Click += new System.EventHandler(this.btnPrimeiro_Click_1);
            // 
            // btnAlfa
            // 
            this.btnAlfa.Location = new System.Drawing.Point(476, 253);
            this.btnAlfa.Name = "btnAlfa";
            this.btnAlfa.Size = new System.Drawing.Size(148, 79);
            this.btnAlfa.TabIndex = 4;
            this.btnAlfa.Text = "Caracteres Alfabéticos\r\n\r\n";
            this.btnAlfa.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAlfa.UseVisualStyleBackColor = true;
            this.btnAlfa.Click += new System.EventHandler(this.btnAlfa_Click_1);
            // 
            // formExercício4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnAlfa);
            this.Controls.Add(this.btnPrimeiro);
            this.Controls.Add(this.btnNumerico);
            this.Controls.Add(this.rchtxtTexto);
            this.Name = "formExercício4";
            this.Text = "formExercício4";
            this.Load += new System.EventHandler(this.formExercício4_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtTexto;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Button btnNumerico;
        private System.Windows.Forms.Button btnPrimeiro;
        private System.Windows.Forms.Button btnAlfa;
    }
}