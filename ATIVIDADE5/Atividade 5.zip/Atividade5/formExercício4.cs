﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class formExercício4 : Form
    {
        public formExercício4()
        {
            InitializeComponent();
        }

        private void formExercício4_Load(object sender, EventArgs e)
        {
            
        }

        private void btnAlfa_Click(object sender, EventArgs e)
        {

        }

        private void btnPrimeiro_Click(object sender, EventArgs e)
        {
           
        }

        private void btnNumerico_Click(object sender, EventArgs e)
        {
            
        }

        private void rchtxtTexto_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnNumerico_Click_1(object sender, EventArgs e)
        {
            int contador = 0;

            for (var x = 0; x < rchtxtTexto.Text.Length; x++)
            {
                if (Char.IsNumber(rchtxtTexto.Text[x]))
                    contador += 1;
            }

            MessageBox.Show("Caracteres numéricos:" + contador);
        }

        private void btnPrimeiro_Click_1(object sender, EventArgs e)
        {
            int x = 0;

            while (x < rchtxtTexto.Text.Length)
            {
                if (Char.IsWhiteSpace(rchtxtTexto.Text[x]))
                {
                    MessageBox.Show("Primeiro caracter branco:" + (x + 1));
                    break;
                }

                x += 1;
            }
        }

        private void btnAlfa_Click_1(object sender, EventArgs e)
        {
            int contador = 0;

            foreach(char c in rchtxtTexto.Text)
            {
                if (Char.IsLetter(c))
                    contador += 1;
            }

            MessageBox.Show("Caracteres ALfabéticos:" + contador);
        }
    }
}
