﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();

            txtLadoB.Clear();

            txtLadoC.Clear();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double Hipotenusa, Cateto1, Cateto2;

            if (double.TryParse(txtLadoA.Text, out double A) &&
                double.TryParse(txtLadoB.Text, out double B) &&
                double.TryParse(txtLadoC.Text, out double C))
            {
                if (A > B && A > C)
                {
                    Hipotenusa = A;

                    if (B < C)
					{
						Cateto1 = B;
						Cateto2 = C;
					}
					else
					{
						Cateto1 = C;
						Cateto2 = B;
					}
				}	
				else
					if (B > A && B > C)
					{
						Hipotenusa = B;
		
						if (A < C)
						{
							Cateto1 = A;
							Cateto2 = C;
						}
						else
						{
							Cateto1 = C;
							Cateto2 = A;
						}		
					}
					else
						if (C > A && C > B)
						{
							Hipotenusa = C;
				
							if (A < B)
							{
								Cateto1 = A;
								Cateto2 = B;
							}
							else
							{
								Cateto1 = B;
								Cateto2 = A;
							}		
						}	
						else
						{
							Hipotenusa = A;
							Cateto1 = B;
							Cateto2 = C;
						}

				if (Hipotenusa >= Cateto1 + Cateto2)
				{
					MessageBox.Show("Esses valores não formam um triângulo");
				}
				else
				{
					if (Hipotenusa == Cateto1 && Cateto1 == Cateto2)
					{
						MessageBox.Show("Triângulo Equilatero");
					}
					else
					{
						if ((Hipotenusa == Cateto1 && Cateto1 != Cateto2) ||
							(Hipotenusa == Cateto2 && Cateto2 != Cateto1) ||
							(Cateto1 == Cateto2 && Cateto2 != Hipotenusa))
						{
							MessageBox.Show("Triângulo Isósceles");
						}
						else
						{
							if (Hipotenusa != Cateto1 && Hipotenusa != Cateto2 &&
								Cateto1 != Cateto2)
							{
								MessageBox.Show("Triângulo Escaleno");
							}
						}
					}
				}
            }
        	else
                MessageBox.Show("Por favor insira dados válidos");
		}
	}
}
