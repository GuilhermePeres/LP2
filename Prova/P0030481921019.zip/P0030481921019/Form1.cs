﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P0030481921019
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string vendas;
            double[,] Vendas = new double[9, 4];
            int i, j;
            string totalsemanas = "";
            string totalmes;
            double Totalmes = 0;
            double TotalGeral = 0;

            for (i=0; i<9; i++)
            {
                for (j = 0; j < 4; j++)
                {
                    vendas = Interaction.InputBox("Digite a quantidade de vendas no mês " + (i + 1) +
                        " na " + (j + 1) + " semana");

                    if (!double.TryParse(vendas, out Vendas[i, j]))
                    {
                        MessageBox.Show("Valores Inválidos!");
                        j--;
                    }
                    else
                    {
                        totalsemanas += ("Total do mês " + (i + 1) + "  Semana: " + (j + 1) +
                         " R$" + Vendas[i, j].ToString("N2"));

                        lstbxVendas.Items.Add(totalsemanas);
                        totalsemanas = "";

                        Totalmes += Vendas[i, j];

                        TotalGeral += Vendas[i, j];
                    }
                }
                totalmes = Totalmes.ToString("N2");
                lstbxVendas.Items.Add(">> Total Mês:R$" + totalmes);
                lstbxVendas.Items.Add("......................");
                Totalmes = 0;
            }
            lstbxVendas.Items.Add("Total Geral: R$" + TotalGeral.ToString("N2"));
        }
    }
}
